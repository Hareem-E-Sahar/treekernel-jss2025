package sample.evaluation.metrics;
import java.util.*;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import sample.evaluation.util.ScoreUtils;


public class MRRCalculator {
    private Map<String, Map<String, Float>> similarityScores;
    private Map<String, ArrayList<String>> referenceClones;
    
    
    public MRRCalculator(Map<String, Map<String, Float>> simScores, Map<String, ArrayList<String>> refClones) {
        this.similarityScores = simScores;
        this.referenceClones  = refClones;
      
    }
   
    public float calculateMRR(String query, ArrayList<String> groundTruth) {
		Map<String, Float> queryScores = similarityScores.get(query);
		if (queryScores == null || queryScores.isEmpty()) {
			System.out.println();
			return 0.0f;  // No scores available for this query
		}
		
		List<Map.Entry<String, Float>> sortedScores = ScoreUtils.getTopScores(queryScores);
		
		if (queryScores == null || queryScores.isEmpty()) {
			return 0.0f;  // No scores available for this query
		}
			
		assert sortedScores.size() <= queryScores.size() : "Error: Filtered list size is larger than original list size!";
			
			
		int rank = 0;
		// Finding the rank of the first relevant item from the ground truth
		for (Entry<String, Float> entry : sortedScores) {
			rank++;
			String foundClone = entry.getKey();
			if (groundTruth.contains(foundClone)) {
				return (float) (1.0 / (rank)); //Reciprocal rank of the first relevant item
			}
		}
		return  0.0f; // No relevant scores found
	}
    
    public float calculateOverallMRR() {
        float sum =  0.0f;
        int count = 0;
        for (String query : referenceClones.keySet()) {
    		    ArrayList<String> groundTruth = referenceClones.get(query);
           	float mrr = calculateMRR(query,groundTruth);
    			  //System.out.println("MRR for "+query+" "+mrr);
            sum += mrr;
            count++;    
        }
        return count > 0 ? sum / count :  0.0f;
    }
}
